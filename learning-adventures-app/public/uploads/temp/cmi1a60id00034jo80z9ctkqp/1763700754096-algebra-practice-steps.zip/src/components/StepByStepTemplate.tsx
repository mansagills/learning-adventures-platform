import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trophy, RotateCcw } from 'lucide-react';
import { Equation } from './AlgebraApp';

interface StepByStepTemplateProps {
  equation: Equation;
  onReset: () => void;
}

const StepByStepTemplate: React.FC<StepByStepTemplateProps> = ({ equation, onReset }) => {
  const color = equation.type === 'one-step' ? 'purple' : 'blue';
  
  const getSteps = () => {
    if (equation.type === 'one-step') {
      if (equation.terms.operation === '+') {
        return [
          { step: 1, description: 'Subtract the constant from both sides', equation: `x + ${equation.terms.constant} - ${equation.terms.constant} = 15 - ${equation.terms.constant}` },
          { step: 2, description: 'Simplify', equation: `x = ${15 - equation.terms.constant}` }
        ];
      } else if (equation.terms.operation === '-') {
        return [
          { step: 1, description: 'Add the constant to both sides', equation: `x - ${equation.terms.constant} + ${equation.terms.constant} = 12 + ${equation.terms.constant}` },
          { step: 2, description: 'Simplify', equation: `x = ${12 + equation.terms.constant}` }
        ];
      } else if (equation.terms.operation === '*') {
        return [
          { step: 1, description: 'Divide both sides by the coefficient', equation: `${equation.terms.coefficient}x ÷ ${equation.terms.coefficient} = 20 ÷ ${equation.terms.coefficient}` },
          { step: 2, description: 'Simplify', equation: `x = ${20 / (equation.terms.coefficient || 1)}` }
        ];
      }
    } else {
      if (equation.terms.operation === '+') {
        return [
          { step: 1, description: 'Subtract the constant from both sides', equation: `${equation.terms.coefficient}x + ${equation.terms.constant} - ${equation.terms.constant} = 13 - ${equation.terms.constant}` },
          { step: 2, description: 'Simplify', equation: `${equation.terms.coefficient}x = ${13 - equation.terms.constant}` },
          { step: 3, description: 'Divide both sides by the coefficient', equation: `x = ${(13 - equation.terms.constant) / (equation.terms.coefficient || 1)}` }
        ];
      } else if (equation.terms.operation === '-') {
        return [
          { step: 1, description: 'Add the constant to both sides', equation: `${equation.terms.coefficient}x - ${equation.terms.constant} + ${equation.terms.constant} = 14 + ${equation.terms.constant}` },
          { step: 2, description: 'Simplify', equation: `${equation.terms.coefficient}x = ${14 + equation.terms.constant}` },
          { step: 3, description: 'Divide both sides by the coefficient', equation: `x = ${(14 + equation.terms.constant) / (equation.terms.coefficient || 1)}` }
        ];
      }
    }
    return [];
  };

  const steps = getSteps();

  return (
    <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
      <CardHeader className={`bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg`}>
        <div className="flex items-center gap-4">
          <Trophy className="w-8 h-8" />
          <div>
            <CardTitle className="text-2xl">🎉 Excellent Work!</CardTitle>
            <p className="text-green-100">Here's how to solve this equation step by step</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <div className={`inline-block p-4 bg-${color}-50 rounded-lg border-2 border-${color}-200`}>
            <p className={`font-mono text-3xl font-bold text-${color}-800`}>
              {equation.equation}
            </p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          {steps.map((step, index) => (
            <Card key={index} className="border-l-4 border-l-green-500 bg-gradient-to-r from-green-50 to-white">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <Badge className="bg-green-500 text-white font-bold text-lg px-3 py-1">
                    {step.step}
                  </Badge>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800 mb-2">{step.description}</p>
                    <p className="font-mono text-xl text-green-800 bg-green-100 p-2 rounded">
                      {step.equation}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button 
            onClick={onReset}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 px-8 text-lg"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Try Another Equation
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default StepByStepTemplate;