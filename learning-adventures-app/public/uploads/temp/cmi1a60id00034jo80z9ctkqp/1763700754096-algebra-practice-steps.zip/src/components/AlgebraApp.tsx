import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import EquationTypeSelector from './EquationTypeSelector';
import PracticeEquationSelector from './PracticeEquationSelector';
import TermsInputForm from './TermsInputForm';
import StepByStepTemplate from './StepByStepTemplate';

export type EquationType = 'one-step' | 'two-step';

export interface Equation {
  id: string;
  equation: string;
  type: EquationType;
  terms: {
    coefficient?: number;
    variable: string;
    constant: number;
    operation: string;
  };
}

const AlgebraApp: React.FC = () => {
  const [selectedType, setSelectedType] = useState<EquationType | null>(null);
  const [selectedEquation, setSelectedEquation] = useState<Equation | null>(null);
  const [isCorrect, setIsCorrect] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const handleReset = () => {
    setSelectedType(null);
    setSelectedEquation(null);
    setIsCorrect(false);
    setAttempts(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-8 shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="text-center bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
            <CardTitle className="text-3xl font-bold">🔢 Algebra Template</CardTitle>
            <p className="text-purple-100">Master one and two-step equations!</p>
          </CardHeader>
        </Card>

        {!selectedType && (
          <EquationTypeSelector onSelect={setSelectedType} />
        )}

        {selectedType && !selectedEquation && (
          <PracticeEquationSelector 
            type={selectedType} 
            onSelect={setSelectedEquation}
            onBack={() => setSelectedType(null)}
          />
        )}

        {selectedEquation && !isCorrect && (
          <TermsInputForm 
            equation={selectedEquation}
            onCorrect={() => setIsCorrect(true)}
            attempts={attempts}
            setAttempts={setAttempts}
            onBack={() => setSelectedEquation(null)}
          />
        )}

        {isCorrect && selectedEquation && (
          <StepByStepTemplate 
            equation={selectedEquation}
            onReset={handleReset}
          />
        )}
      </div>
    </div>
  );
};

export default AlgebraApp;