import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { EquationType } from './AlgebraApp';

interface EquationTypeSelectorProps {
  onSelect: (type: EquationType) => void;
}

const EquationTypeSelector: React.FC<EquationTypeSelectorProps> = ({ onSelect }) => {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 hover:border-purple-300 bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-purple-600 mb-2">
            📐 One-Step Equations
          </CardTitle>
          <p className="text-gray-600">Simple equations with one operation</p>
        </CardHeader>
        <CardContent className="text-center">
          <div className="mb-4 p-4 bg-purple-50 rounded-lg">
            <p className="font-mono text-lg text-purple-800">x + 5 = 12</p>
            <p className="font-mono text-lg text-purple-800">3x = 15</p>
            <p className="font-mono text-lg text-purple-800">x - 4 = 8</p>
          </div>
          <Button 
            onClick={() => onSelect('one-step')}
            className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg shadow-lg transform transition hover:scale-105"
          >
            Practice One-Step Equations
          </Button>
        </CardContent>
      </Card>

      <Card className="hover:shadow-xl transition-all duration-300 hover:scale-105 cursor-pointer border-2 hover:border-blue-300 bg-white/90 backdrop-blur-sm">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-blue-600 mb-2">
            🎯 Two-Step Equations
          </CardTitle>
          <p className="text-gray-600">Equations requiring two operations</p>
        </CardHeader>
        <CardContent className="text-center">
          <div className="mb-4 p-4 bg-blue-50 rounded-lg">
            <p className="font-mono text-lg text-blue-800">2x + 3 = 11</p>
            <p className="font-mono text-lg text-blue-800">3x - 5 = 10</p>
            <p className="font-mono text-lg text-blue-800">4x + 7 = 23</p>
          </div>
          <Button 
            onClick={() => onSelect('two-step')}
            className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 rounded-lg shadow-lg transform transition hover:scale-105"
          >
            Practice Two-Step Equations
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default EquationTypeSelector;