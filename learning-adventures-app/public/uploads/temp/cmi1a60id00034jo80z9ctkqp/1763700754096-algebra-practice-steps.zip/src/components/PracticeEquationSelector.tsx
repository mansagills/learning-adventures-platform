import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft } from 'lucide-react';
import { EquationType, Equation } from './AlgebraApp';

interface PracticeEquationSelectorProps {
  type: EquationType;
  onSelect: (equation: Equation) => void;
  onBack: () => void;
}

const oneStepEquations: Equation[] = [
  { id: '1', equation: 'x + 7 = 15', type: 'one-step', terms: { variable: 'x', constant: 7, operation: '+' } },
  { id: '2', equation: '4x = 20', type: 'one-step', terms: { coefficient: 4, variable: 'x', constant: 0, operation: '*' } },
  { id: '3', equation: 'x - 3 = 12', type: 'one-step', terms: { variable: 'x', constant: 3, operation: '-' } },
  { id: '4', equation: 'x/5 = 6', type: 'one-step', terms: { variable: 'x', constant: 5, operation: '/' } },
];

const twoStepEquations: Equation[] = [
  { id: '5', equation: '2x + 5 = 13', type: 'two-step', terms: { coefficient: 2, variable: 'x', constant: 5, operation: '+' } },
  { id: '6', equation: '3x - 4 = 14', type: 'two-step', terms: { coefficient: 3, variable: 'x', constant: 4, operation: '-' } },
  { id: '7', equation: '5x + 8 = 23', type: 'two-step', terms: { coefficient: 5, variable: 'x', constant: 8, operation: '+' } },
  { id: '8', equation: '4x - 7 = 17', type: 'two-step', terms: { coefficient: 4, variable: 'x', constant: 7, operation: '-' } },
];

const PracticeEquationSelector: React.FC<PracticeEquationSelectorProps> = ({ type, onSelect, onBack }) => {
  const equations = type === 'one-step' ? oneStepEquations : twoStepEquations;
  const color = type === 'one-step' ? 'purple' : 'blue';

  return (
    <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
      <CardHeader className={`bg-gradient-to-r from-${color}-600 to-${color}-700 text-white rounded-t-lg`}>
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <CardTitle className="text-2xl">
              Choose a {type === 'one-step' ? 'One-Step' : 'Two-Step'} Equation
            </CardTitle>
            <p className={`text-${color}-100`}>Select an equation to practice identifying terms and coefficients</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid gap-4">
          {equations.map((equation) => (
            <Card 
              key={equation.id}
              className={`hover:shadow-lg transition-all duration-200 hover:scale-102 cursor-pointer border-2 hover:border-${color}-300 bg-gradient-to-r from-white to-${color}-50`}
              onClick={() => onSelect(equation)}
            >
              <CardContent className="p-6 flex items-center justify-between">
                <div className="text-center flex-1">
                  <p className={`font-mono text-2xl font-bold text-${color}-800 mb-2`}>
                    {equation.equation}
                  </p>
                  <Badge variant="secondary" className={`bg-${color}-100 text-${color}-700`}>
                    Click to practice
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default PracticeEquationSelector;