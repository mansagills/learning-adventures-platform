import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import { Equation } from './AlgebraApp';

interface TermsInputFormProps {
  equation: Equation;
  onCorrect: () => void;
  attempts: number;
  setAttempts: (attempts: number) => void;
  onBack: () => void;
}

const TermsInputForm: React.FC<TermsInputFormProps> = ({ 
  equation, 
  onCorrect, 
  attempts, 
  setAttempts, 
  onBack 
}) => {
  const [coefficient, setCoefficient] = useState('');
  const [variable, setVariable] = useState('');
  const [constant, setConstant] = useState('');
  const [operation, setOperation] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAttempts(attempts + 1);

    const isCorrect = 
      (equation.terms.coefficient ? parseInt(coefficient) === equation.terms.coefficient : coefficient === '' || coefficient === '1') &&
      variable.toLowerCase() === equation.terms.variable.toLowerCase() &&
      parseInt(constant) === equation.terms.constant &&
      operation === equation.terms.operation;

    if (isCorrect) {
      setFeedback('Perfect! You correctly identified all terms and coefficients!');
      setIsSuccess(true);
      setTimeout(() => onCorrect(), 1500);
    } else {
      setFeedback(`Not quite right. Try again! (Attempt ${attempts + 1})`);
      setIsSuccess(false);
    }
  };

  const color = equation.type === 'one-step' ? 'purple' : 'blue';

  return (
    <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
      <CardHeader className={`bg-gradient-to-r from-${color}-600 to-${color}-700 text-white rounded-t-lg`}>
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="text-white hover:bg-white/20"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <CardTitle className="text-2xl">Identify Terms & Coefficients</CardTitle>
            <p className={`text-${color}-100`}>Enter the parts of this equation</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <div className={`inline-block p-4 bg-${color}-50 rounded-lg border-2 border-${color}-200`}>
            <p className={`font-mono text-3xl font-bold text-${color}-800`}>
              {equation.equation}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {equation.type === 'two-step' && (
              <div>
                <Label htmlFor="coefficient" className="text-lg font-semibold">Coefficient</Label>
                <Input
                  id="coefficient"
                  type="number"
                  value={coefficient}
                  onChange={(e) => setCoefficient(e.target.value)}
                  placeholder="Enter coefficient"
                  className="text-lg"
                />
              </div>
            )}
            
            <div>
              <Label htmlFor="variable" className="text-lg font-semibold">Variable</Label>
              <Input
                id="variable"
                value={variable}
                onChange={(e) => setVariable(e.target.value)}
                placeholder="Enter variable (e.g., x)"
                className="text-lg"
              />
            </div>
            
            <div>
              <Label htmlFor="constant" className="text-lg font-semibold">Constant</Label>
              <Input
                id="constant"
                type="number"
                value={constant}
                onChange={(e) => setConstant(e.target.value)}
                placeholder="Enter constant"
                className="text-lg"
              />
            </div>
            
            <div>
              <Label htmlFor="operation" className="text-lg font-semibold">Operation</Label>
              <Input
                id="operation"
                value={operation}
                onChange={(e) => setOperation(e.target.value)}
                placeholder="Enter operation (+, -, *, /)"
                className="text-lg"
              />
            </div>
          </div>

          <Button 
            type="submit" 
            className={`w-full bg-gradient-to-r from-${color}-500 to-${color}-600 hover:from-${color}-600 hover:to-${color}-700 text-white font-semibold py-3 text-lg`}
          >
            Check Answer
          </Button>
        </form>

        {feedback && (
          <div className={`mt-4 p-4 rounded-lg flex items-center gap-2 ${
            isSuccess ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'
          }`}>
            {isSuccess ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
            <p className="font-semibold">{feedback}</p>
          </div>
        )}

        <div className="mt-4 text-center">
          <Badge variant="outline">Attempts: {attempts}</Badge>
        </div>
      </CardContent>
    </Card>
  );
};

export default TermsInputForm;