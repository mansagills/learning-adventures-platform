import React from 'react';
import AlgebraApp from '@/components/AlgebraApp';

const Index: React.FC = () => {
  return <AlgebraApp />;
};

export default Index;